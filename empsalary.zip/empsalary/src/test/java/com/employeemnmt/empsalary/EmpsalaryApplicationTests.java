package com.employeemnmt.empsalary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpsalaryApplicationTests {

	@Test
	void contextLoads() {
	}

}
